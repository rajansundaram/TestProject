#!/bin/bash
packdir=$1
thetime="`date +\"%H:%m\"`"
curl -X POST \
  https://mm.pheaacloud.org/hooks/cyd4egawkinj3n7jbzirh93h3w \
  -H 'cache-control: no-cache' \
  -H 'content-type: application/json' \
  -d '{"channel": "buildstatus","text": ":nerd_face: PACKER Build Completed @'${thetime}' for '${packdir^^}' :nerd_face:"}'
curl -X POST \
  https://hooks.slack.com/services/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 \
  -H 'cache-control: no-cache' \
  -H 'content-type: application/json' \
  -d '{"text": ":nerd_face: PACKER Build Completed @'${thetime}' for '${packdir^^}' :nerd_face:"}'
