#!/bin/bash
appname=confluent
#appver=XXX
#appdir=XXX
#export XXX_HOME=${appdir}
#export PATH=$PATH:${XXX_HOME}/bin
################################################################################



#BASE BUILD CONFIG GOES HERE



################################################################################
sudo echo "Completed Install"

