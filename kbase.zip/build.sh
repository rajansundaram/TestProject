#!/bin/bash
appname=confluent
#appver=XXX
#appdir=XXX
#export XXX_HOME=${appdir}
#export PATH=$PATH:${XXX_HOME}/bin
################################################################################
sudo yum update -y
sudo yum upgrade -y
sleep 15
sudo yum install -y java epel-release
export JAVA_HOME=/usr/lib/jvm/jre-1.8.0-openjdk.x86_64
export PATH=$JAVA_HOME/bin:$PATH
################################################################################



#BASE BUILD CONFIG GOES HERE



################################################################################
sudo echo "Completed Install"

